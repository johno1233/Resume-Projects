//Created by John on 2/11/2018.

package edu.cs1699.pitt.edu.triviagame2;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;



public class PlayActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private int numQ = 0;
    private static final int TOTAL_QUESTIONS = 5;
    private int score = 0;
    private Map<String, String> terms;
    boolean ttsReady = false;
    private boolean ttsMake;
    private TextToSpeech tts;

//    private FirebaseDatabase wordList;
//    private DatabaseReference wordRef;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_activity);

//        wordList = FirebaseDatabase.getInstance();
//        wordRef = wordList.getReference();

        ttsMake = getIntent().getBooleanExtra("make", false);
        if(ttsMake == true){
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener(){
                @Override
                public void onInit(int status) {
                    ttsReady = true;
                }
            });
        }

        this.terms = new HashMap(); //hash map to store the words and their definitions

        Scanner sc = new Scanner(getResources().openRawResource(R.raw.terms));
        String word = "";
        String def;
        int i = 1;
        while(sc.hasNext()){
            if(i % 2 != 0) word = sc.nextLine();
            else{
                def = sc.nextLine();
                terms.put(word, def);
            }
            i++;
        }
        sc.close();
        i = 1;
        try{
            Scanner newSc = new Scanner(openFileInput("new_words.txt"));
            while(newSc.hasNextLine()){
                if(i % 2 != 0) word = newSc.nextLine();
                else{
                    def = newSc.nextLine();
                    terms.put(word, def);
                }
                i++;
            }
        }catch(FileNotFoundException e){
            ((ListView) findViewById(R.id.answers)).setOnItemClickListener(this);
            showQuestion();
        }
        ((ListView) findViewById(R.id.answers)).setOnItemClickListener(this);
//        wordRef.setValue(terms);
        showQuestion();
    }
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){

        String guess = adapterView.getItemAtPosition(i).toString(); // gets the user's answer
        String answer = terms.get(((TextView)findViewById(R.id.question)).getText().toString()); // gets the answer to the question
        if(guess.equals(answer)){
            score++;
            Toast.makeText(this, "Correct! Score: " + score, Toast.LENGTH_SHORT).show();
        }else Toast.makeText(this, "Incorrect! Score: " + score, Toast.LENGTH_SHORT).show();
        if(numQ > TOTAL_QUESTIONS){
            setResult(-1234, new Intent().putExtra("score", score));
            if(ttsMake == true) tts.stop();
            finish();
        }
        showQuestion();
    }
    public void showQuestion(){
        TextView qtext = findViewById(R.id.question);
        String qWord = new ArrayList(terms.keySet()).get(new Random().nextInt(terms.keySet().size())).toString(); // get the question word
        if(ttsReady == true){
            tts.speak(qWord, TextToSpeech.QUEUE_FLUSH, null);
        }
        String ans = terms.get(qWord); // get the correct answer to above word
        qtext.setText(qWord);
        Map<String, String> tempTerms = new HashMap(terms);
        tempTerms.remove(qWord);

        List<String> defList = new ArrayList(tempTerms.values());
        Collections.shuffle(defList);
        defList = defList.subList(0, 3);
        defList.add(ans);
        Collections.shuffle(defList);

        ArrayAdapter ad = new ArrayAdapter(this,android.R.layout.simple_list_item_1, new ArrayList(defList));
        ((ListView)findViewById(R.id.answers)).setAdapter(ad);
        ((ProgressBar)findViewById(R.id.progressBar)).setProgress(numQ);
        if(ttsReady == true){
            for(int i = 0; i < defList.size(); i++){
                tts.speak(defList.get(i), TextToSpeech.QUEUE_ADD, null);
            }
        }
        numQ++;
    }

}
