package edu.cs1699.pitt.edu.triviagame2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by John on 2/11/2018.
 */

public class ScoreActivity extends AppCompatActivity {
    private int highScore;
    private ArrayList<String> scoreHistoryList;
    private TextView scorePercent;
    private ListView scoreHistory;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.score_activity);

        scorePercent = findViewById(R.id.ScorePercent);
        scoreHistory = findViewById(R.id.ScoreHistory);

        getData();
        updateData();
    }

    public void getData(){
        highScore = getIntent().getExtras().getInt("HighScore");
        scoreHistoryList = getIntent().getStringArrayListExtra("scores");
    }
    public void updateData(){
        scorePercent.setText(getIntent().getStringExtra("name")+ highScore + "%");
        ArrayAdapter ad = new ArrayAdapter(this,android.R.layout.simple_list_item_1, scoreHistoryList);
        scoreHistory.setAdapter(ad);
    }
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        scoreHistoryList = savedInstanceState.getStringArrayList("ScoreHistory");
        highScore = savedInstanceState.getInt("HighScore");

    }
    protected void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putStringArrayList("ScoreHistory", scoreHistoryList);
        savedInstanceState.putInt("HighScore", highScore);

    }
    public void backOnClick(View view){
        finish();
    }
}
