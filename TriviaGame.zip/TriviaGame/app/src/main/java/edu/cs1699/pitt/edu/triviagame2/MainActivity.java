package edu.cs1699.pitt.edu.triviagame2;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.*;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;

import static android.app.NotificationChannel.DEFAULT_CHANNEL_ID;


public class MainActivity extends AppCompatActivity{
    private static final int PIC_REQ_CODE = 2345;
    private int highScore;
    private ArrayList<String> scores;
    private boolean ttsMake = false;
    private String playerName;
    private int[] topTen = new int[10];
    private int numScores = 0;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            ActivityCompat.requestPermissions(this, new String[] {"android.permission.CAMERA"}, PIC_REQ_CODE);

            SharedPreferences p = getPreferences(0);
            highScore = p.getInt("HighScore", 0);
            scores = new ArrayList(p.getStringSet("History", new HashSet()));

            startTakePictureIntent();

            playerName = getIntent().getStringExtra("name");

            Switch music = findViewById(R.id.Music);
            music.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    musicOnChanged(b);
                }
            });
            Switch s = findViewById(R.id.TextToSpeech);
            s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    ttsMake = isChecked;
                }
            });

        }
        public void startTakePictureIntent(){
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if(intent.resolveActivity(getPackageManager()) != null){
                startActivityForResult(intent, PIC_REQ_CODE);
            }
        }
        public void playOnClick(View v){
            Intent intent = new Intent(this, PlayActivity.class);
            intent.putExtra("make", ttsMake);
            intent.putExtra("name", playerName);
            startActivityForResult(intent, 1234);
        }
        public void addOnClick(View v){
            final Dialog addWord = new Dialog(this);
            addWord.setContentView(R.layout.add_activity);
            addWord.show();
            Button ok = addWord.findViewById(R.id.Ok);
            ok.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    EditText editWord = addWord.findViewById(R.id.NewWord);
                    EditText editDef = addWord.findViewById(R.id.NewDefinition);

                    try{
                        PrintStream f = new PrintStream(MainActivity.this.openFileOutput("new_words.txt", MODE_APPEND));
                        f.println(editWord.getText().toString());
                        f.println(editDef.getText().toString());
                        f.close();
                    }catch(FileNotFoundException e){
                        Log.e("AddWord", "File not found");
                    }
                addWord.dismiss();
                }
            });
        }
        public void scoreOnClick(View v){
            Intent intent = new Intent(this.getApplicationContext(), ScoreActivity.class);
            intent.putExtra("scores", scores);
            intent.putExtra("HighScore", highScore);
            intent.putExtra("name", playerName);
            startActivity(intent);
        }
        public void getTopTen(){
            for(int i = 0; i < topTen.length; i++){
                if(highScore > topTen[i]){
                    topTen[i] = highScore;
                    break;
                }else if(highScore == topTen[i]){
                    topTen[i] = highScore;
                    break;
                }
            }
            Toast.makeText(this, "Top Ten Scores Updated!", Toast.LENGTH_SHORT).show();

            NotificationCompat.Builder mbuilder = new NotificationCompat.Builder(this, DEFAULT_CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Notify")
                    .setContentText("Top Ten Updated")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);


        }
        public void musicOnChanged(boolean b){
            Intent intent = new Intent(this, BackgroundMusic.class);
            if(b == true){
                startService(intent);
            }else if(b == false){
                stopService(intent);
            }
        }
        protected void onRestoreInstanceState(Bundle savedInstanceState){
            super.onRestoreInstanceState(savedInstanceState);
            highScore = savedInstanceState.getInt("HighScore");
            scores = (ArrayList)savedInstanceState.getSerializable("History");
        }
        protected void onSaveInstanceState(Bundle savedInstanceState){
            super.onSaveInstanceState(savedInstanceState);
            savedInstanceState.putInt("HighScore", highScore);
            savedInstanceState.putSerializable("History", scores);
        }

        protected void onActivityResult(int reqCode, int resCode, Intent intent){
            super.onActivityResult(reqCode, resCode, intent);
            if(reqCode == 1234 && resCode == -1234){
                int score = getScore(intent);
                String currentDateTime = DateFormat.getDateTimeInstance().format(new Date());
                scores.add(currentDateTime + "\t\t" + score + "%");
                if(score >= highScore){
                    highScore = score;
                    getTopTen();
                }
            }
            if(reqCode == PIC_REQ_CODE && resCode == RESULT_OK){
                Bundle extras = intent.getExtras();
                Bitmap image = (Bitmap) extras.get("data");
                QuickContactBadge player = findViewById(R.id.playerProfile);
                player.setImageBitmap(image);
            }
        }
        public int getScore(Intent intent){
            int score = intent.getIntExtra("score", 0);
            score = score * 100;
            score = score / 5;
            return score;
        }
        protected void onStop(){
            super.onStop();
            SharedPreferences.Editor e = getPreferences(0).edit();
            e.putInt("HighScore", highScore);
            e.putStringSet("History", new HashSet(scores));
            e.apply();
        }
}