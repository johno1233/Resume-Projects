// Created by John on 2/11/2018.

package edu.cs1699.pitt.edu.triviagame2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import android.widget.EditText;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity);

    }

    public void okOnClick(View v){
        EditText editWord = findViewById(R.id.NewWord);
        EditText editDef = findViewById(R.id.NewDefinition);

        try{
            PrintStream f = new PrintStream(AddActivity.this.openFileOutput("new_words.txt", MODE_APPEND));
            f.println(editWord.getText().toString());
            f.println(editDef.getText().toString());
            f.close();
        }catch(FileNotFoundException e){
            Log.e("AddWord", "File not found");
        }
        finish();
    }
}
