package edu.cs1699.pitt.edu.triviagame2;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

/**
 * Created by John on 2/11/2018.
 */

public class BackgroundMusic extends Service {
    private static final String str = null;
    MediaPlayer player;

    public IBinder onBind(Intent intent){
        return null;
    }
    @Override
    public void onCreate(){
        super.onCreate();
        player = MediaPlayer.create(this, R.raw.miiplaza);
        player.setLooping(true);
        player.setVolume(100, 100);

    }
    public int onStartCommand(Intent intent, int flag, int startID){
        player.start();
        return Service.START_NOT_STICKY;
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        player.stop();
        player.release();
    }
}
