//John Wartonick

package edu.cs1699.pitt.edu.triviagame2;

import android.content.*;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.*;
import android.widget.*;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.*;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.*;


public class LogInActivity extends FragmentActivity
        implements GoogleApiClient.OnConnectionFailedListener,
        GoogleApiClient.ConnectionCallbacks {

    private static final int REQ_CODE = 1234;
    private GoogleApiClient google;


    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in_activity);

        SignInButton button = findViewById(R.id.sign_in_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSignInClick(v);
            }
        });
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        google = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, options)
                .addConnectionCallbacks(this)
                .build();
    }

    public void onSignInClick(View view){
        Intent intent = Auth.GoogleSignInApi.getSignInIntent(google);
        startActivityForResult(intent, REQ_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);

        if(requestCode == REQ_CODE) {
            GoogleSignInResult res = Auth.GoogleSignInApi.getSignInResultFromIntent(intent);
            if (res.isSuccess()) {
                GoogleSignInAccount acct = res.getSignInAccount();
                Toast.makeText(this, "Signed in as: " + acct.getDisplayName(), Toast.LENGTH_LONG).show();
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("name", acct.getDisplayName());
                startActivity(i);
            } else {
                Toast.makeText(this, "Login failed!", Toast.LENGTH_LONG).show();
            }
        }
    }
    public void onConnectionFailed(ConnectionResult connectionResult){
//       Log("onConnectionFailed");
    }
    public void onConnected(Bundle bundle){
//        log("onConnected");
    }
    public void onConnectionSuspended(int i){
//        log("onConnectionSuspended");
    }
}
