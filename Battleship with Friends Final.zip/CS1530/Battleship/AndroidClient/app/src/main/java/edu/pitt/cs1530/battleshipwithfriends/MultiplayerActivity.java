package edu.pitt.cs1530.battleshipwithfriends;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class MultiplayerActivity extends AppCompatActivity {

    private int currentBoard;
    private Button btnPlayerBoard;
    private Button btnOpponentBoard;
    private TableLayout lytPlayerBoard;
    TableLayout lytOpponentBoard;
    TextView txtStatusLabel;

    public static ArrayList<Ship> ships = new ArrayList<>();
    int shipNum = 0;
    Boolean startPlacement = true;
    public String firstPlace = "";
    Boolean IS_DEBUG_MODE = false;
    public ArrayList<String> shipAbbr = new ArrayList<>();
    public ArrayList<String> shots = new ArrayList<>();
    public ArrayList<String> placedCoords = new ArrayList<>();
    boolean setupPhase = true;
    ArrayList<String> board = new ArrayList<>();

    int[] playerBoardButtonIDs = new int[]{
            R.id.buttonPlA1, R.id.buttonPlA2, R.id.buttonPlA3, R.id.buttonPlA4, R.id.buttonPlA5, R.id.buttonPlA6, R.id.buttonPlA7, R.id.buttonPlA8, R.id.buttonPlA9, R.id.buttonPlA10,
            R.id.buttonPlB1, R.id.buttonPlB2, R.id.buttonPlB3, R.id.buttonPlB4, R.id.buttonPlB5, R.id.buttonPlB6, R.id.buttonPlB7, R.id.buttonPlB8, R.id.buttonPlB9, R.id.buttonPlB10,
            R.id.buttonPlC1, R.id.buttonPlC2, R.id.buttonPlC3, R.id.buttonPlC4, R.id.buttonPlC5, R.id.buttonPlC6, R.id.buttonPlC7, R.id.buttonPlC8, R.id.buttonPlC9, R.id.buttonPlC10,
            R.id.buttonPlD1, R.id.buttonPlD2, R.id.buttonPlD3, R.id.buttonPlD4, R.id.buttonPlD5, R.id.buttonPlD6, R.id.buttonPlD7, R.id.buttonPlD8, R.id.buttonPlD9, R.id.buttonPlD10,
            R.id.buttonPlE1, R.id.buttonPlE2, R.id.buttonPlE3, R.id.buttonPlE4, R.id.buttonPlE5, R.id.buttonPlE6, R.id.buttonPlE7, R.id.buttonPlE8, R.id.buttonPlE9, R.id.buttonPlE10,
            R.id.buttonPlF1, R.id.buttonPlF2, R.id.buttonPlF3, R.id.buttonPlF4, R.id.buttonPlF5, R.id.buttonPlF6, R.id.buttonPlF7, R.id.buttonPlF8, R.id.buttonPlF9, R.id.buttonPlF10,
            R.id.buttonPlG1, R.id.buttonPlG2, R.id.buttonPlG3, R.id.buttonPlG4, R.id.buttonPlG5, R.id.buttonPlG6, R.id.buttonPlG7, R.id.buttonPlG8, R.id.buttonPlG9, R.id.buttonPlG10,
            R.id.buttonPlH1, R.id.buttonPlH2, R.id.buttonPlH3, R.id.buttonPlH4, R.id.buttonPlH5, R.id.buttonPlH6, R.id.buttonPlH7, R.id.buttonPlH8, R.id.buttonPlH9, R.id.buttonPlH10,
            R.id.buttonPlI1, R.id.buttonPlI2, R.id.buttonPlI3, R.id.buttonPlI4, R.id.buttonPlI5, R.id.buttonPlI6, R.id.buttonPlI7, R.id.buttonPlI8, R.id.buttonPlI9, R.id.buttonPlI10,
            R.id.buttonPlJ1, R.id.buttonPlJ2, R.id.buttonPlJ3, R.id.buttonPlJ4, R.id.buttonPlJ5, R.id.buttonPlJ6, R.id.buttonPlJ7, R.id.buttonPlJ8, R.id.buttonPlJ9, R.id.buttonPlJ10
    };

    int[] opponentBoardButtonIDs = new int[]{
            R.id.buttonOpA1, R.id.buttonOpA2, R.id.buttonOpA3, R.id.buttonOpA4, R.id.buttonOpA5, R.id.buttonOpA6, R.id.buttonOpA7, R.id.buttonOpA8, R.id.buttonOpA9, R.id.buttonOpA10,
            R.id.buttonOpB1, R.id.buttonOpB2, R.id.buttonOpB3, R.id.buttonOpB4, R.id.buttonOpB5, R.id.buttonOpB6, R.id.buttonOpB7, R.id.buttonOpB8, R.id.buttonOpB9, R.id.buttonOpB10,
            R.id.buttonOpC1, R.id.buttonOpC2, R.id.buttonOpC3, R.id.buttonOpC4, R.id.buttonOpC5, R.id.buttonOpC6, R.id.buttonOpC7, R.id.buttonOpC8, R.id.buttonOpC9, R.id.buttonOpC10,
            R.id.buttonOpD1, R.id.buttonOpD2, R.id.buttonOpD3, R.id.buttonOpD4, R.id.buttonOpD5, R.id.buttonOpD6, R.id.buttonOpD7, R.id.buttonOpD8, R.id.buttonOpD9, R.id.buttonOpD10,
            R.id.buttonOpE1, R.id.buttonOpE2, R.id.buttonOpE3, R.id.buttonOpE4, R.id.buttonOpE5, R.id.buttonOpE6, R.id.buttonOpE7, R.id.buttonOpE8, R.id.buttonOpE9, R.id.buttonOpE10,
            R.id.buttonOpF1, R.id.buttonOpF2, R.id.buttonOpF3, R.id.buttonOpF4, R.id.buttonOpF5, R.id.buttonOpF6, R.id.buttonOpF7, R.id.buttonOpF8, R.id.buttonOpF9, R.id.buttonOpF10,
            R.id.buttonOpG1, R.id.buttonOpG2, R.id.buttonOpG3, R.id.buttonOpG4, R.id.buttonOpG5, R.id.buttonOpG6, R.id.buttonOpG7, R.id.buttonOpG8, R.id.buttonOpG9, R.id.buttonOpG10,
            R.id.buttonOpH1, R.id.buttonOpH2, R.id.buttonOpH3, R.id.buttonOpH4, R.id.buttonOpH5, R.id.buttonOpH6, R.id.buttonOpH7, R.id.buttonOpH8, R.id.buttonOpH9, R.id.buttonOpH10,
            R.id.buttonOpI1, R.id.buttonOpI2, R.id.buttonOpI3, R.id.buttonOpI4, R.id.buttonOpI5, R.id.buttonOpI6, R.id.buttonOpI7, R.id.buttonOpI8, R.id.buttonOpI9, R.id.buttonOpI10,
            R.id.buttonOpJ1, R.id.buttonOpJ2, R.id.buttonOpJ3, R.id.buttonOpJ4, R.id.buttonOpJ5, R.id.buttonOpJ6, R.id.buttonOpJ7, R.id.buttonOpJ8, R.id.buttonOpJ9, R.id.buttonOpJ10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplayer);

        btnPlayerBoard = (Button) findViewById(R.id.btnPlayerBoard);
        btnOpponentBoard = (Button) findViewById(R.id.btnOpponentBoard);
        lytPlayerBoard = (TableLayout) findViewById(R.id.playerBoard);
        lytOpponentBoard = (TableLayout) findViewById(R.id.opponentBoard);
        txtStatusLabel = (TextView) findViewById(R.id.statusLabel);

        // Disable Player Board Button & Hide Opponent Board on Start
        currentBoard = 0;
        btnPlayerBoard.setEnabled(false);
        lytOpponentBoard.setVisibility(View.GONE);


        initialize();
    }

    public void setStatusLabel(String text) {
        txtStatusLabel.setText(text);
    }

    public void switchBoard(View view) {
        if(currentBoard == 0) {
            // Switch to Opponent Board
            lytPlayerBoard.setVisibility(View.GONE);
            lytOpponentBoard.setVisibility(View.VISIBLE);
            btnPlayerBoard.setEnabled(true);
            btnOpponentBoard.setEnabled(false);
            currentBoard = 1;
        } else {
            // Switch to Player Board
            lytOpponentBoard.setVisibility(View.GONE);
            lytPlayerBoard.setVisibility(View.VISIBLE);
            btnOpponentBoard.setEnabled(true);
            currentBoard = 0;
        }
    }

    void initialize() {
        // Start the game!
        disableOponentGrid();
        enablePlayerGrid();
        Singleplayer.createShips();
        ships = new ArrayList<Ship>(Singleplayer.ships.values());

        setStatusLabel("Enter the starting Coord for " + ships.get(0).toString());

        // Add a button pressed listener to each button
        for(int i=0; i<100; i++) {
            Button btn = (Button) findViewById(playerBoardButtonIDs[i]);
            btn.setOnClickListener(buttonPressedListener);
            Button btn2 = (Button) findViewById(opponentBoardButtonIDs[i]);
            btn2.setOnClickListener(buttonPressedListener);
        }

        //mainMenuButton.setVisible(false);
//        Singleplayer.cpuCreateBoard();
    }

    public void goToMainMenu(View view) {
        Intent intent = new Intent(MultiplayerActivity.this, MainMenuActivity.class);
        startActivity(intent);
    }

    private void disableOponentGrid() {
        // Disables all buttons on the opponent grid
        Log.d("Op Grid", "Disabling");
        for(int i=0; i<100; i++) {
            Button btn = (Button) findViewById(opponentBoardButtonIDs[i]);
            btn.setEnabled(false);
        }
    }

    private void enableOponentGrid() {
        // Enables all buttons on the opponent grid
        Log.d("Op Grid", "Enabliong");
        for(int i=0; i<100; i++) {
            Button btn = (Button) findViewById(opponentBoardButtonIDs[i]);
            if(btn.getText().equals("Hit") || btn.getText().equals("Miss")){
                continue;
            }
            btn.setEnabled(true);
        }
    }

    private void disablePlayerGrid() {
        // Disables all buttons on the player grid
        Log.d("Pl Grid", "Disabling");
        for(int i=0; i<100; i++) {
            Button btn = (Button) findViewById(playerBoardButtonIDs[i]);
            btn.setEnabled(false);
        }
    }

    private void enablePlayerGrid() {
        // Enables all buttons on the player grid
        Log.d("Pl Grid", "Enabliong");
        for(int i=0; i<100; i++) {
            Button btn = (Button) findViewById(playerBoardButtonIDs[i]);
            btn.setEnabled(true);
        }
    }

    private View.OnClickListener buttonPressedListener = new View.OnClickListener()
    {

        public void onClick(View v)
        {
            if(setupPhase) {
                try {
                    place(v);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                fire(v);
            }
        }

    };

    private void place(View v) throws Exception {
        Button b = (Button) findViewById(v.getId());
        Log.d("pressed place", b.getText().toString());
        Ship curr = ships.get(shipNum);

        updatePlaceBoard(b.getText().toString(), curr.length - 1, curr.abbr);
        // placedCoords.add(b.getText()+curr.abbr);
        if (!startPlacement) {
            setStatusLabel("Enter the ending Coord for " + curr.toString());
        } else {
            shipNum++;
            if (shipNum != 5) {
                setStatusLabel("Enter the starting Coord for " + ships.get(shipNum).toString());
            } else {
                // statusLabel.setText("Done Placing Ships, waiting for match to begin");
                Log.d("Status", "Done placing ships!");
                setupPhase = false;
                disablePlayerGrid();

                ArrayList<String> board = new ArrayList<>();

                for(int i=0; i<100; i++) {
                    Button btn = (Button) findViewById(playerBoardButtonIDs[i]);
                    String coord = btn.getText().toString();
                    if (coord.length() >= 4) {
                        board.add(coord);
                    }
                }

                Log.d("Board:", board.toString());
//                Singleplayer.storeBoard(board);
                new uploadBoardTask(board).execute();

            }
        }
    }

    private void fire(View v) {
        Button b = (Button) findViewById(v.getId());
        Log.d("pressed fire", b.getText().toString());
        String shot = b.getText().toString();
        //TODO Create Fire Task
       new fireTask(shot, b).execute();


    }

    public void updatePlaceBoard(String p, int length, String abbr) {
        // Method that disables buttons that need to be disabled, and updates button
        // labels

        // Add ship abbreviation to list
        shipAbbr.add(abbr);
        if (IS_DEBUG_MODE) {
            System.out.println(startPlacement);
        }

        // If we are placing the "head" of the ship
        if (startPlacement) {
            ArrayList<String> options = new ArrayList<>();
            // int x = 0;

            // Seperate number and letter from string.
            char letter = p.charAt(0);
            int num;
            num = Integer.parseInt(p.substring(1, p.length()));
            // Save this location for when we place the "tail" of the ship
            firstPlace = letter + "" + num;

            // Add all possible tail values, depending on the length of the ship
            char newL = (char) (letter - length);
            String newS = newL + "" + num;
            options.add(newS);

            newL = (char) (letter + length);
            newS = newL + "" + num;
            options.add(newS);

            int newN = num - length;
            newS = letter + "" + newN;
            options.add(newS);

            newN = num + length;
            newS = letter + "" + newN;
            options.add(newS);

            // Create a copy of options because we will be destorying options2
            ArrayList<String> options2 = new ArrayList<>();
            for (String option : options) {
                options2.add(option);
            }

            // Checks to make sure intersections are not allowed.
            for (String option : options2) {
                char letter1 = firstPlace.charAt(0);
                int num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

                char letter2 = option.charAt(0);
                int num2 = Integer.parseInt(option.substring(1, option.length()));

                // Lists all buttons that would be disabled if the user were to select that
                // specific option
                ArrayList<String> path = new ArrayList<>();
                if (letter1 == letter2) {
                    if (IS_DEBUG_MODE) {
                        System.out.println("Same Letters");
                    }

                    for (int i = num1; i < num2; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                    for (int i = num2; i < num1; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                }
                if (num1 == num2) {
                    for (char c = letter1; c < letter2; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                    for (char c = letter2; c < letter1; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                }

                if (IS_DEBUG_MODE) {
                    System.out.println("Removing Intersections");
                }

                // Searches for the buttons in path, and if it finds that the button isn't
                // occupied, it removes it.
                for(int j=0; j<100; j++) {
                    Button button = (Button) findViewById(playerBoardButtonIDs[j]);
                    if (path.contains(button.getText())) {
                        path.remove(button.getText());
                    }
                }

                // When the above for loop finishes, path will contain the coordinates of any
                // occupied button,
                // so if path isn't empty, the path would intersect with another ship, so we
                // remove that option
                if (IS_DEBUG_MODE) {
                    System.out.println("Checking Intersections");
                }

                if (path.size() != 0) {
                    options.remove(option);
                }

            }

            if (IS_DEBUG_MODE) {
                System.out.println("Disabling Buttons");
            }

            // Disable any button that isn't contained in the good options list.
            for(int k=0; k<100; k++) {
                Button b = (Button) findViewById(playerBoardButtonIDs[k]);
                if (!options.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    b.setEnabled(false);
                }
            }

            // Tells the method that we have placed the "head" of our ship
            startPlacement = false;

        }
        // we've placed the head, so now we are placing the tail
        else {
            ArrayList<String> greyedOut = new ArrayList<>();
            // int x = 0;

            // Break up strings letter and number
            char letter2 = p.charAt(0);
            int num2;
            num2 = Integer.parseInt(p.substring(1, p.length()));

            // Break up the firstPlace letter and number
            char letter1 = firstPlace.charAt(0);
            int num1;
            num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

            String newS = letter1 + "" + num1;
            greyedOut.add(newS);
            newS = letter2 + "" + num2;
            greyedOut.add(newS);

            if (IS_DEBUG_MODE) {
                System.out.println("Building Path");
            }

            // Add all the buttons between button1 and button2 to be greyed out
            if (letter1 == letter2) {
                for (int i = num1; i < num2; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
                for (int i = num2; i < num1; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
            }
            if (num1 == num2) {
                for (char c = letter1; c < letter2; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
                for (char c = letter2; c < letter1; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
            }

            // Disable buttons for the path, sets abbreviations, enables buttons that should
            // be enabled afterwards
            if (IS_DEBUG_MODE) {
                System.out.println("Enabling Buttons");
            }

            for(int l=0; l<100; l++) {
                Button b = (Button) findViewById(playerBoardButtonIDs[l]);

                if (greyedOut.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    placedCoords.add(b.getText().toString());
                    if (greyedOut.contains(b.getText())) {
                        b.setText(b.getText() + abbr);
                        b.setBackgroundColor(Color.parseColor("#696969"));
                        shipAbbr.add(b.getText().toString());
                    }

                    b.setEnabled(false);

                } else {
                    b.setEnabled(true);
                }

            }

            // Says we are ready for the next head ship
            startPlacement = true;

        }

    }

    void updatePlayerGrid(String button) {
        System.out.println("Update Player GRID" + button);
        for(int i=0; i<100; i++) {
            Button b = (Button) findViewById(playerBoardButtonIDs[i]);
            StringBuilder sb = new StringBuilder();
            sb.append(b.getText());
            String bText = sb.toString();
            if(bText.equals(button)) {
                b.setBackgroundColor(Color.parseColor("#10A6EA"));
            }
            if(bText.startsWith(button) && bText.length() > 3){
                b.setBackgroundColor(Color.parseColor("#EF1F14"));
            }
        }
    }

    private class updateStatsTask extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            if(objects[0] == "Win"){ clientToServer.updateStats(clientToServer.email, "win");}
            else if(objects[0] == "Lose"){clientToServer.updateStats(clientToServer.email, "loss");}
            return null;
        }
    }
    public class uploadBoardTask extends AsyncTask<Void, Void, Boolean> {
        ArrayList<String> board = new ArrayList<>();
        String message;
        uploadBoardTask(ArrayList<String> b ) {
            board = b;

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                 message = clientToServer.uploadBoard(board, clientToServer.email, clientToServer.gameID);

            } catch (Exception e) {
                e.printStackTrace();
            }

            Log.d("Upload Board Message",message );
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {


            if(message.equalsIgnoreCase("Waiting For Other Player To Finish")){
                setStatusLabel(message);
                disableOponentGrid();
                new waitTurnTask().execute();
            }
            else{
                setStatusLabel("Your Turn");
                enableOponentGrid();
                switchBoard(null);
            }

        }
    }

    public class waitTurnTask extends AsyncTask<Void, Void, Boolean> {
        String message;
        waitTurnTask() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                Log.d("Being Wait", "Waiting ");
                message = clientToServer.waitTurn();

            } catch (Exception e) {
                return false;
            }

            Log.d("waitTurn Message",message );
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            if(!message.equals("")){

                if(message.contains("Lose")){
//                    new updateStatsTask().execute("Lose");
                    setStatusLabel(message);
                    Button mmButton = (Button)findViewById(R.id.multiplayerMMButton);
                    mmButton.setVisibility(View.VISIBLE);
                    if(currentBoard == 1){
                        switchBoard(null);
                    }
                    //Show Main Menu button
                }
                else{
                    updatePlayerGrid(message);
                    setStatusLabel("Your Turn");

                    enableOponentGrid();
                    if(currentBoard == 0){
                        switchBoard(null);
                    }

                }

            }


        }
    }
    public class fireTask extends AsyncTask<Void, Void, Boolean> {
        String message;
        String shot;
        Button button;
        fireTask(String s, Button b) {
            shot = s;
            button = b;
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                Log.d("Firing Shot", shot);
                message = clientToServer.fireShot(clientToServer.email,clientToServer.gameID,shot);

            } catch (Exception e) {
                return false;
            }

            Log.d("Fire shot message",message );
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            setStatusLabel("You " + message);
            if (message.contains("Hit")) {
                button.setText("Hit");
                 button.setBackgroundColor(Color.parseColor("#EF1F14"));
            } else {
                button.setText("Miss");
                button.setBackgroundColor(Color.parseColor("#10A6EA"));
            }
            button.setEnabled(false);
            disableOponentGrid();
            if(message.contains("Win")){
//                new updateStatsTask().execute("Win");
                //Show Main Menu button
                Button mmButton = (Button)findViewById(R.id.multiplayerMMButton);
                mmButton.setVisibility(View.VISIBLE);

                if(currentBoard == 1){
                    switchBoard(null);
                }                         

            }
            else{
                new waitTurnTask().execute();
            }


        }
    }



}
