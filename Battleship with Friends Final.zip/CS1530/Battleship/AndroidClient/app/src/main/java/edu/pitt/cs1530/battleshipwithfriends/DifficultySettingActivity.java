package edu.pitt.cs1530.battleshipwithfriends;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;

import java.util.HashMap;

public class DifficultySettingActivity extends AppCompatActivity {
    private String mode = "";

    private setDifficultyTask mTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_difficulty_setting);
        Intent intent = getIntent();
        this.mode = intent.getStringExtra("mode");

    }

    public void goToMainMenu(View view){
        Intent intent = new Intent(DifficultySettingActivity.this, MainMenuActivity.class);
        startActivity(intent);
    }



    public void onEasyClick(View view) {
        mTask = new setDifficultyTask(1);
        mTask.execute();
    }
    public void onHardClick(View view){
        mTask = new setDifficultyTask(2);
        mTask.execute();
    }
    public void onImpossibleClick(View view){
        mTask = new setDifficultyTask(3);
        mTask.execute();
    }

    public class setDifficultyTask extends AsyncTask<Void, Void, Boolean> {
        int difficulty = 0;
        setDifficultyTask(int diff) {
            difficulty = diff;
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                clientToServer.uploadSettings(difficulty);

            } catch (Exception e) {
                return false;
            }

            Log.d("Uploaded Settings", "Found Player");
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            AlertDialog alertDialog = new AlertDialog.Builder(DifficultySettingActivity.this).create();
            alertDialog.setTitle("Alert");
            switch (difficulty){
                case 1:
                    alertDialog.setMessage("Difficulty Has Been Set to Easy");
                case 2:
                    alertDialog.setMessage("Difficulty Has Been Set to Hard");
                case 3:
                    alertDialog.setMessage("Difficulty Has Been Set to Impossible");
            }

            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();


        }
    }
}
