package edu.pitt.cs1530.battleshipwithfriends;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.HashMap;

public class StatsActivity extends AppCompatActivity {
    TextView email = null;
    private getStatsTask mTask = null;
    private Integer wins;
    private Integer losses;
    private Integer plusMinus;
    TextView winsTV = null;
    TextView lossesTV = null;
    TextView plusMinusTV = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        System.out.println(clientToServer.email);
        email = findViewById(R.id.statsEmail);
        email.setText(clientToServer.email);

        winsTV = findViewById(R.id.statsWinAmt);
        lossesTV = findViewById(R.id.statsLossAmt2);
        plusMinusTV = findViewById(R.id.statsPlusMinusAmt);

        mTask = new getStatsTask();
        mTask.execute();


    }

    public void goToMainMenu(View view) {
        Intent intent = new Intent(StatsActivity.this, MainMenuActivity.class);
        startActivity(intent);
    }

    public class getStatsTask extends AsyncTask<Void, Void, Boolean> {

        getStatsTask() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                HashMap<String, Integer> stats = clientToServer.getStats(clientToServer.email);
                wins = stats.get("wins");
                losses = stats.get("losses");
                plusMinus = stats.get("plusMinus");
                System.out.println(stats);




            } catch (Exception e) {
                return false;
            }

            Log.d("Found Player", "Found Player");
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            System.out.println(wins);
            winsTV.setText(wins.toString());
            lossesTV.setText(losses.toString());
            plusMinusTV.setText(plusMinus.toString());

        }

    }
}
