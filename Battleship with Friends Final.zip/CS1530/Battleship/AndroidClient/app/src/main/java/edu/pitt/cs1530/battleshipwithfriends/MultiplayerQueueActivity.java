package edu.pitt.cs1530.battleshipwithfriends;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.lang.Exception;

public class MultiplayerQueueActivity extends AppCompatActivity  {


    private MultiplayerQueueTask mTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplayer_queue);
        TextView tv = (TextView) findViewById(R.id.textView);
//        tv.setText("Waiting For Players 2");
        mTask = new MultiplayerQueueTask();
        mTask.execute();

    }


    public class MultiplayerQueueTask extends AsyncTask<Void, Void, Boolean> {

        MultiplayerQueueTask() {

        }

        @Override
        protected Boolean doInBackground(Void... params)  {
            // TODO: attempt authentication against a network service.
            Boolean res;
            try {
                String gameID = clientToServer.multiPlayerGame(clientToServer.email);
                clientToServer.gameID = gameID;

            } catch (Exception e) {
                return false;
            }

            Log.d("Found Player", "Found Player");
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            Intent multiplayerIntent = new Intent(MultiplayerQueueActivity.this, MultiplayerActivity.class);
            startActivity(multiplayerIntent);
        }

    }
}
