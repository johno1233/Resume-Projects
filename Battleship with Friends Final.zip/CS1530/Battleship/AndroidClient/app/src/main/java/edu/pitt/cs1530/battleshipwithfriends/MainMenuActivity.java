package edu.pitt.cs1530.battleshipwithfriends;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainMenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    public void onSinglePlayerClick(View v){
        Intent intent = new Intent(MainMenuActivity.this, SinglePlayerGameActivity.class);
        startActivity(intent);
    }
    public void onMultiplayerClick(View v){
        System.out.println("Testing Main Menu CLick");
        Intent intent = new Intent(MainMenuActivity.this, MultiplayerQueueActivity.class);
        startActivity(intent);
    }
    public void onPracticeClick(View v){
        Singleplayer.practiceMode = true;
        Intent intent = new Intent(MainMenuActivity.this, SinglePlayerGameActivity.class);
        startActivity(intent);
    }
    public void onStatsClick(View v){
        System.out.println("Testing Stats CLick");
        Intent intent = new Intent(MainMenuActivity.this, StatsActivity.class);
        startActivity(intent);
    }
    public void onSettingsClick(View v){
        System.out.println("Testing Settings CLick");
        Intent intent = new Intent(MainMenuActivity.this, DifficultySettingActivity.class);
        startActivity(intent);
    }
}
