from flask import Flask, g
from flask_restful import Resource, Api, reqparse
import shelve
from collections import defaultdict

# Create an instance of Flask
app = Flask(__name__)

def get_board_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("board", writeback=True)
    return db

@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

class setupBoard(Resource):

    def post(self):
        import json

        abbrToNames = {
            "CR": {"name": "Cruiser", "length": 3},
            "BS": {"name": "Battleship", "length": 4},
            "CA": {"name": "Carrier", "length": 5},
            "DS": {"name": "Destroyer", "length": 2},
            "SB": {"name": "Submarine", "length": 3},
        }

        data = {}

        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("gameID", required=True)
        parser.add_argument("board", required=True)

        args = parser.parse_args()
        gameID = args["gameID"]
        email = args["email"]
        strBoard = args["board"]
        db = get_board_db()

        print(strBoard)

        board = strBoard.replace("[", "")
        board = board.replace("]", "")
        board = board.replace(",", "")
        board = board.split(" ")

        print(board, type(board))

        playerBoard = {}
        playerCoords = {}

        for coord in board:
            if len(coord) > 4:
                c = coord[:3]
                s = coord[3:]
            else:
                c = coord[:2]
                s = coord[2:]

            print(c, s)

            shipName = abbrToNames[s]["name"]
            playerCoords[c] = shipName

            if shipName not in playerBoard:
                playerBoard[shipName] = abbrToNames[s]
                playerBoard[shipName]["hits"] = 0
                playerBoard[shipName]["coords"] = []

            if c not in playerBoard[shipName]["coords"]:
                playerBoard[shipName]["coords"].append(c)

        if gameID not in db:
            db[gameID] = {}
            db[gameID]["currentPlayer"] = "Waiting For Other Player"
            message = "Waiting For Other Player To Finish"
        else:
            message = "Ready To Play"
            db[gameID]["currentPlayer"] = args["email"]
        db[gameID][email] = {
            "board": playerBoard,
            "coords": playerCoords,
            "shots": [],
            "sunkShips": [],
        }

        # Make sure this line is commented out when not testing
        # db[gameID]["crg50@pitt.edu"] = {
        #     "board": playerBoard,
        #     "coords": playerCoords,
        #     "shots": [],
        #     "sunkShips": [],
        # }

        data = playerBoard
        return ({"message": message, "gameID": gameID, "data": data}, 201)

    def get(self):
        data = [
            {"name": "Carrier", "length": 5},
            {"name": "Battleship", "length": 4},
            {"name": "Cruiser", "length": 3},
            {"name": "Submarine", "length": 3},
            {"name": "Destroyer", "length": 2},
        ]

        return {"message": "Ship Info", "data": data}, 200

    def delete(self):
        parser = reqparse.RequestParser()
        parser.add_argument("gameID", required=True)

        args = parser.parse_args()
        db = get_board_db()

        if args["gameID"] in db:
            del db[args["gameID"]]

        return  {"Message": "Game Deleted"}, 200
