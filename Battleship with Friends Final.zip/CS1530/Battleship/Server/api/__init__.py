import markdown
import os
import shelve

# Import the framework
from flask import Flask, g
from flask_restful import Resource, Api, reqparse

# Create an instance of Flask
app = Flask(__name__)

# Create the API
api = Api(app)

from multiplayer import multiplayer
from login import loginUser
from register import registerUser
from stats import Stats

from setupBoard import setupBoard
from game import Game
from settings import Settings
from game import DeleteGames

api.add_resource(registerUser, "/register")
api.add_resource(loginUser, "/login")
api.add_resource(multiplayer, "/multiplayer")
api.add_resource(setupBoard, "/board")
api.add_resource(Game, "/fire")
api.add_resource(Stats, "/stats")
api.add_resource(Settings, "/settings")
api.add_resource(DeleteGames, "/delete")

