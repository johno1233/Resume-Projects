import markdown
import os
import shelve

# Import the framework
from flask import Flask, g
from flask_restful import Resource, Api, reqparse
import hashlib

# Create an instance of Flask
app = Flask(__name__)

def get_user_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("username",  writeback=True)
    return db

@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

class loginUser(Resource):

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("shaPassword", required=True)

        args = parser.parse_args()
        email = args["email"]
        db = get_user_db()

        if email not in db:
            return {"message": "User Not Found"}, 404

        dbPassword = db[email]["shaPassword"]
        dbSalt = db[email]["salt"]
        enteredPassword = args["shaPassword"] + dbSalt
        enteredPassword = hashlib.sha256(enteredPassword.encode("utf-8")).hexdigest()

        print(dbPassword, enteredPassword)
        
        if dbPassword == enteredPassword:
            return {"message": "User Logged In"}, 200

        return {"message": "Incorrect Password"}, 401
