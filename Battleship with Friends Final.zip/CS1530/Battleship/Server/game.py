from flask import Flask, g
from flask_restful import Resource, Api, reqparse
import shelve
from collections import defaultdict
from stats import update_plus_minus, update_record

# Create an instance of Flask
app = Flask(__name__)


def get_board_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("board", writeback=True)
    return db


def getLastShot(email, db, gameID):
    otherPlayer = [x for x in db[gameID] if x != email and x != "currentPlayer"][0]
    if len(db[gameID][otherPlayer]["shots"]) == 0:
        return ""
    if len(db[gameID][email]["sunkShips"]) == 5:
        remaining = len(db[gameID][otherPlayer]["sunkShips"])
        update_record(email, "loss")
        update_plus_minus(email, remaining*-1)
        return "You Lose"
    else:
        return db[gameID][otherPlayer]["shots"][-1]


def getCurrentTurn(gameID, email):
    db = get_board_db()
    currentPlayer = db[gameID]["currentPlayer"]
    shot = getLastShot(email, db, gameID)
    return (
        {
            "gameID": gameID,
            "currentPlayer": db[gameID]["currentPlayer"],
            "lastShot": shot,
        },
        200,
    )


@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


def get_multiplayer_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("multiplayer", writeback=True)
    return db


class DeleteGames(Resource):
    def get(self):
        boarddb = get_board_db()
        multiDB = get_multiplayer_db()
        print(list(multiDB.keys()))
        print(list(boarddb.keys()))
        multiDB.clear()
        boarddb.clear()
        return (
            {"Message": "sucess", "board": dict(boarddb), "multiplayer": dict(multiDB)},
            200,
        )


class Game(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("gameID", required=True)
        parser.add_argument("shot")

        args = parser.parse_args()
        email = args["email"]
        gameID = args["gameID"]
        shot = args["shot"]
        db = get_board_db()

        print(args)
        print(list(db.keys()))

        if shot == None:
            return getCurrentTurn(gameID, email)

        print(db[gameID].keys())

        otherPlayer = [x for x in db[gameID] if x != email and x != "currentPlayer"][0]
        otherPlayerCoords = db[gameID][otherPlayer]["coords"]
        otherPlayerBoard = db[gameID][otherPlayer]["board"]

        db[gameID][email]["shots"].append(shot)
        db[gameID]["currentPlayer"] = otherPlayer

        message = ""
        if shot not in otherPlayerCoords:
            return ({"message": "Missed", "gameID": args["gameID"]}, 201)
        else:
            message += "You Hit Their "
            hitShip = db[gameID][otherPlayer]["coords"][shot]
            message += hitShip
            db[gameID][otherPlayer]["board"][hitShip]["hits"] += 1

            if (
                db[gameID][otherPlayer]["board"][hitShip]["hits"]
                == db[gameID][otherPlayer]["board"][hitShip]["length"]
            ):
                message += " and it Sunk"
                db[gameID][otherPlayer]["sunkShips"].append(hitShip)

            if len(db[gameID][otherPlayer]["sunkShips"]) == 5:
                remaining = len(db[gameID][email]["sunkShips"])
                update_record(email, "win")
                update_plus_minus(email, remaining)
                message = "You Win!"

        return ({"message": message, "gameID": gameID, "data": dict(db)}, 201)

