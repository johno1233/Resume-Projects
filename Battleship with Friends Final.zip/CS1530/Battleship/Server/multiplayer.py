import markdown
import os
import shelve

# Import the framework
from flask import Flask, g
from flask_restful import Resource, Api, reqparse

# Create an instance of Flask
app = Flask(__name__)

def get_multiplayer_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("multiplayer", writeback=True)
    return db

@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

class multiplayer(Resource):

    def post(self):
        import hashlib

        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)

        args = parser.parse_args()
        email = args["email"]
        db = get_multiplayer_db()

        for k in db.keys():
            print(k)

        if email not in db:
            db[email] = ""
            return {"message": "User Added to Queue"}, 200

        if db[email] != "":
            otherPlayer = db[email]
            gameID = hashlib.sha256(
                (otherPlayer + email).encode("utf-8")
            ).hexdigest()
            del db[email]
            return {
                "message": "Ready To Play!",
                "otherPlayer": otherPlayer,
                "gameID": gameID,
            }
        if len(db.keys()) < 2:
            return (
                {
                    "message": "Waiting for More Players",
                    "data": dict(db),
                    "matchup": db[email],
                },
                200,
            )
        else:
            otherPlayer = ""
            for player in db.keys():
                if player != email:
                    otherPlayer = player
                    break

            db[otherPlayer] = email
            gameID = hashlib.sha256(
                (email + otherPlayer).encode("utf-8")
            ).hexdigest()

            del db[email]

            return {
                "message": "Ready To Play!",
                "otherPlayer": otherPlayer,
                "gameID": gameID,
            }
