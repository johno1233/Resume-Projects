import shelve
from flask import Flask, g
from flask_restful import Resource, Api, reqparse

# Create an instance of Flask
app = Flask(__name__)

def get_stats_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("stats", writeback=True)
    return db

@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def update_record(email, outcome):
    db = get_stats_db()
    if email not in db:
        db[email] = {"wins":0, "losses":0, "plusMinus":0}
    stats = db[email]

    if outcome == "win":
        stats["wins"]+=1
    else:
        stats["losses"]+=1
    #stats["plusMinus"] = stats["plusMinus"] + num_ships

def update_plus_minus(email, num_ships):
    db = get_stats_db()
    if email not in db:
        db[email] = {"wins":0, "losses":0, "plusMinus":0}
    stats = db[email]
    stats["plusMinus"] = stats["plusMinus"] + num_ships
    
class Stats(Resource):

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("outcome", required=True)
        
        args = parser.parse_args()
        email = args["email"]
        outcome = args["outcome"]
        db = get_stats_db()
        
        if email not in db:
            db[email] = {"wins":0, "losses":0, "plusMinus":0}

        stats = db[email]
        
        if outcome == "win":
            stats["wins"] = stats["wins"] + 1
        elif outcome == "loss":
            stats["losses"] = stats["losses"] + 1
        else:
            return {"message": "Invalid Outcome"}, 400

        return 200

    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)

        args = parser.parse_args()
        email = args["email"]
        db = get_stats_db()
        
        if email not in db:
            db[email] = {"wins":0, "losses":0, "plusMinus":0}
            
        stats = db[email]

        return {"wins":stats["wins"], "losses":stats["losses"], "plusMinus":stats["plusMinus"]}, 200   
