import pickle

with pickle.load(open("test.db", "w+b")) as db:
    db["test1"] = "test2"

    pickle.dump(db, "test.db")
