import markdown
import os
import shelve

# Import the framework
from flask import Flask, g
from flask_restful import Resource, Api, reqparse
import time
import hashlib
import smtplib 
from email.message import EmailMessage

# Create an instance of Flask
app = Flask(__name__)


def get_user_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("username", writeback=True)
    return db


@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def send_email(recipient):
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.ehlo()
        server.starttls()
        server.login("battleshipwithfriendsCS1530@gmail.com", "battleship1530")
        msg = EmailMessage()
        msg['Subject'] = "Welcome!"
        msg['From'] = "battleshipwithfriendsCS1530@gmail.com"
        msg['To'] = recipient
        msg.set_content("Thank you for registering for Battleship with Friends!")
        server.send_message(msg)
    except:
        print("Failed to send welcome email")

class registerUser(Resource):
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("shaPassword", required=True)

        args = parser.parse_args()
        email = args["email"]
        shaPassword = args["shaPassword"]
        db = get_user_db()

        if email in db:
            return {"message": "User Not Registered"}, 401

        db[email] = args

        currentTime = time.time()
        currentTimeHash  = hashlib.sha256(str(currentTime).encode("utf-8")).hexdigest()

        shaPassword = shaPassword+currentTimeHash
        shaPassword = hashlib.sha256(shaPassword.encode("utf-8")).hexdigest()

        db[email]["salt"] = currentTimeHash
        db[email]["shaPassword"] = shaPassword

        send_email(email)

        return {"message": "User Registered"}, 201
