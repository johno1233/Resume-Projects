import shelve
from flask import Flask, g
from flask_restful import Resource, Api, reqparse

# Create an instance of Flask
app = Flask(__name__)

def get_settings_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = shelve.open("settings", writeback=True)
    return db

@app.teardown_appcontext
def teardown_db(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def getDiff(email):
    db = get_settings_db()
    if email not in db.keys():
        db[email] = {}
        db[email]["diff"] = 1
        return {"message" : "Error, email not found in settings. Setting diff to 1", "diff": 1}, 404
    diff = int(db[email]["diff"])
    return {"message": "Found Diff", "diff": diff}, 200

class Settings(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("email", required=True)
        parser.add_argument("difficulty")
        
        args = parser.parse_args()
        email = args["email"]
        if args["difficulty"] == None :
            return getDiff(email)
        db = get_settings_db()
        
        diff = args["difficulty"]
        if email not in db:
            db[email] = {}
        db[email]["diff"] = diff
        return  {"message": "Set Difficulty", "data": db[email]}, 201