import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Scanner;

//import com.oracle.javafx.jmx.json.*
import org.json.*;

import jdk.nashorn.internal.parser.JSONParser;

public class Client {
    public static void main(String[] args) throws InterruptedException {
        for (String a : args) {
            System.out.println(a);
        }
        if (!register(args[0], args[1])) {
            System.out.println("User already registered");
        }
        Boolean loginStatus = login(args[0], args[1]);
        if (!loginStatus) {
            System.exit(0);
        }
        // multiPlayerGame(args[0]);
        ArrayList<HashMap<String, String>> board = createBoard(args[0]);

        uploadBoard(board, args[0], "12345");

    }

    public static boolean register(String email, String password) {
        String url = "http://localhost:8080/register";

        HashMap<String, String> data = new HashMap<String, String>();
        data.put("email", email);
        data.put("shaPassword", Sha256Hash.calculateHash(password));

        int num = HttpRequest.post(url).form(data).code();
        return num < 400;
    }

    public static boolean login(String email, String password) {
        String url = "http://localhost:8080/login";

        HashMap<String, String> data = new HashMap<String, String>();
        data.put("email", email);
        data.put("shaPassword", Sha256Hash.calculateHash(password));

        int num = HttpRequest.post(url).form(data).code();
        return num < 400;
    }

    public static HashMap<String, String> multiPlayerGame(String email) throws InterruptedException {
        String url = "http://localhost:8080/multiplayer";
        HashMap<String, String> data = new HashMap<String, String>();
        data.put("email", email);
        String res = HttpRequest.post(url).form(data).body();
        while (!res.contains("Ready To")) {
            System.out.println(res);
            Thread.sleep(1000);
            res = HttpRequest.post(url).form(data).body();
        }
        // HashMap<String, String> game = jsonToMap(res);
        String game = res;
        System.out.println(game);
        HashMap<String, String> testMap = jsonToMap(game);
        System.out.println(testMap);

        return testMap;
    }

    public static boolean uploadBoard(ArrayList<HashMap<String, String>> b, String email, String gameID) {
        // TODO
        String url = "http://localhost:8080/board";
        // Ugg screw you java
        JSONObject j = new JSONObject();
        j.put("email", email);
        j.put("gameID", gameID);
        j.put("board", b);

        String response = HttpRequest.post(url).form(j.toMap()).body();
        System.out.println(response);

        return true;
    }

    public static ArrayList<HashMap<String, String>> createBoard(String email) {
        ArrayList<HashMap<String, String>> board = new ArrayList<>();
        String url = "http://localhost:8080/board";
        String res = HttpRequest.get(url).body();
        // System.out.println(res);
        // HashMap<String, String> test = jsonToMap(res);
        // System.out.println(test);
        // Fuck Java
        JSONObject jObject = new JSONObject(res);
        // System.out.println(jObject);
        JSONArray data = (JSONArray) jObject.get("data");
        // System.out.println(data.length());
        for (int i = 0; i < data.length(); i++) {
            JSONObject j = data.getJSONObject(i);
            int length = j.getInt("length");
            String name = j.getString("name");
            System.out.println(j.getString("name") + " " + String.valueOf(j.getInt("length")));

            Scanner scan = new Scanner(System.in);
            String coords = "";
            for (int x = 0; x < length; x++) {
                String tmp = scan.nextLine();
                coords = coords + " " + tmp;
            }
            HashMap<String, String> tmpMap = new HashMap<>();
            tmpMap.put("name", name);
            tmpMap.put("coords", coords);
            board.add(tmpMap);

        }
        return board;
    }

    public static HashMap<String, String> jsonToMap(String t) {

        HashMap<String, String> map = new HashMap<String, String>();
        JSONObject jObject = new JSONObject(t);
        Iterator<?> keys = jObject.keys();

        while (keys.hasNext()) {
            String key = (String) keys.next();
            String value = jObject.getString(key);
            map.put(key, value);

        }
        return map;
    }

}
