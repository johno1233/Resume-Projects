import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.control.PasswordField;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;

public class MultiplayerBoard extends Application {
    Boolean IS_DEBUG_MODE = false;
    int shipNum = 0;
    Boolean startPlacement = true;
    public String firstPlace = "";

    public ArrayList<String> shipAbbr = new ArrayList<>();

    public ArrayList<Ship> ships = new ArrayList<>();
    public ArrayList<String> shots = new ArrayList<>();

    public ArrayList<String> placedCoords = new ArrayList<>();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button a1;

    @FXML
    private Button a11;

    @FXML
    private GridPane playerGrid;

    @FXML
    private Pane background;

    @FXML
    private GridPane oponentGrid;

    @FXML
    private TextField textfield;

    @FXML
    private Label boardLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private Button mainmenuButton;

    @FXML
    void goToMainMenu(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    void fire(ActionEvent event) throws InterruptedException, IOException {
        Button b = (Button) event.getSource();
        System.out.println(b.getText());
        shots.add(b.getText());
        disableOponentGrid();
        String status = clientToServer.fireShot(clientToServer.email, clientToServer.gameID, b.getText());
        statusLabel.setText(status);
        if (status.contains("Win")) {
            System.out.println("You win!");
            mainmenuButton.setVisible(true);
            // Go to Rematch
            // Parent root =
            // FXMLLoader.load(getClass().getResource("DesktopClient/src/Rematch.fxml"));
            // Stage stage = new Stage();
            // stage.setTitle("Multiplayer Mode");
            // stage.setScene(new Scene(root, 800, 800));
            // stage.show();
            // Stage s = (Stage) statusLabel.getScene().getWindow();
            // s.close();
        }
        if (status.contains("Hit")) {
            b.setText("Hit");
        } else {
            b.setText("Miss");
        }
        Task<String> turnCheck = new Task<String>() {
            @Override
            protected String call() throws Exception {
                String message = clientToServer.waitTurn();
                System.out.println(message);
                if (message.contains("Lose")) {
                    System.out.println("You Lose");
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            try {

                                // Set Status Label to message, enable grid
                                statusLabel.setText("You Lose");
                                disableOponentGrid();
                            } catch (Exception e) {
                                // TODO: handle exception
                            }

                        }
                    });
                    // Go to main menu
                    mainmenuButton.setVisible(true);
                    // Parent root =
                    // FXMLLoader.load(getClass().getResource("DesktopClient/src/Rematch.fxml"));
                    // Stage stage = new Stage();
                    // stage.setTitle("Multiplayer Mode");
                    // stage.setScene(new Scene(root, 800, 800));
                    // stage.show();
                    // Stage s = (Stage) statusLabel.getScene().getWindow();
                    // s.close();
                } else {
                    updatePlayerGrid(message);
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            try {

                                // Set Status Label to message, enable grid
                                statusLabel.setText("Your Turn");
                                enableOponentGrid();
                            } catch (Exception e) {
                                // TODO: handle exception
                            }

                        }
                    });
                }

                // Thread.sleep(10000);
                return "";
            }
        };

        Thread th = new Thread(turnCheck);
        th.setDaemon(true);
        th.start();

    }

    @FXML
    void place(ActionEvent event) {
        Button b = (Button) event.getSource();
        System.out.println(b.getText());
        Ship curr = ships.get(shipNum);

        updatePlaceBoard(b.getText(), curr.length - 1, curr.abbr);
        // placedCoords.add(b.getText()+curr.abbr);
        if (!startPlacement) {
            statusLabel.setText("Enter the ending Coord for " + curr.toString());
        } else {
            shipNum++;
            if (shipNum != 5) {
                statusLabel.setText("Enter the starting Coord for " + ships.get(shipNum).toString());
            } else {
                // statusLabel.setText("Done Placing Ships, waiting for match to begin");
                disablePlayerGrid();

                ArrayList<String> board = new ArrayList<>();

                ObservableList<Node> test = playerGrid.getChildren();
                int counter = 0;
                for (Node t : test) {

                    Button button = (Button) t;
                    String coord = button.getText();
                    if (coord.length() >= 4) {
                        board.add(coord);
                    }
                    counter++;
                    if (counter == 100)
                        break;
                }

                // for (String coord : placedCoords) {cgra
                // if (coord.length() >= 3) {
                // board.add(coord);
                // }
                // }
                System.out.println(board);
                String status = clientToServer.uploadBoard(board, clientToServer.email, clientToServer.gameID);
                statusLabel.setText(status);

                Task<String> turnCheck = new Task<String>() {
                    @Override
                    protected String call() throws Exception {
                        String message = clientToServer.waitTurn();
                        if (!message.equals("")) {
                            updatePlayerGrid(message);
                        }
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    // Set Status Label to message, enable grid
                                    statusLabel.setText("Your Turn");
                                    enableOponentGrid();
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }

                            }
                        });
                        // Thread.sleep(10000);
                        return "";
                    }
                };

                Thread th = new Thread(turnCheck);
                th.setDaemon(true);
                th.start();

                // TODO add Checks for Not ready
                // if (status.contains("Ready")) {
                // enableOponentGrid();
                // }
            }

        }
        // System.out.println(placedCoords);

    }

    @FXML
    void quitGame(ActionEvent event) {

    }

    @FXML
    void setIP(ActionEvent event) {

    }

    @FXML
    void initialize() throws InterruptedException {
        disableOponentGrid();
        enablePlayerGrid();
        ships.add(new Ship("Carrier", "CA", 5));
        ships.add(new Ship("Battleship", "BS", 4));
        ships.add(new Ship("Cruiser", "CR", 3));
        ships.add(new Ship("Submarine", "SB", 3));
        ships.add(new Ship("Destroyer", "DS", 2));

        // placeShips();
        statusLabel.setText("Enter the starting Coord for " + ships.get(0).toString());

    }

    void enablePlayerGrid() {
        // Enables all the buttons on the player's (bottom) grid
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(false);
            counter++;
            if (counter == 100)
                break;
        }
    }

    void disablePlayerGrid() {
        // Disables all the buttons on the player's (bottom) grid)
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(true);
            counter++;
            if (counter == 100)
                break;
        }
    }

    void updatePlayerGrid(String button) {
        // Disables all the buttons on the player's (bottom) grid)
        System.out.println(button);
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            if (b.getText().equals(button)) {
                // Missed
                System.out.println(b.getText());
                b.setStyle("-fx-background-color: #10A6EA;");
            } else if (b.getText().startsWith(button) && b.getText().length() != 3) {
                // Hit
                System.out.println(b.getText());
                b.setStyle("-fx-background-color: #EF1F14;");
            }
            counter++;
            if (counter == 100)
                break;
        }
    }

    public void updatePlaceBoard(String p, int length, String abbr) {
        // Method that disables buttons that need to be disabled, and updates button
        // labels

        // Add ship abbreviation to list
        shipAbbr.add(abbr);
        if (IS_DEBUG_MODE) {
            System.out.println(startPlacement);
        }

        // If we are placing the "head" of the ship
        if (startPlacement) {
            ArrayList<String> options = new ArrayList<>();
            // int x = 0;

            // Seperate number and letter from string.
            char letter = p.charAt(0);
            int num;
            num = Integer.parseInt(p.substring(1, p.length()));
            // Save this location for when we place the "tail" of the ship
            firstPlace = letter + "" + num;

            // Add all possible tail values, depending on the length of the ship
            char newL = (char) (letter - length);
            String newS = newL + "" + num;
            options.add(newS);

            newL = (char) (letter + length);
            newS = newL + "" + num;
            options.add(newS);

            int newN = num - length;
            newS = letter + "" + newN;
            options.add(newS);

            newN = num + length;
            newS = letter + "" + newN;
            options.add(newS);

            // Create a copy of options because we will be destorying options2
            ArrayList<String> options2 = new ArrayList<>();
            for (String option : options) {
                options2.add(option);
            }

            // Checks to make sure intersections are not allowed.
            for (String option : options2) {
                char letter1 = firstPlace.charAt(0);
                int num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

                char letter2 = option.charAt(0);
                int num2 = Integer.parseInt(option.substring(1, option.length()));

                // Lists all buttons that would be disabled if the user were to select that
                // specific option
                ArrayList<String> path = new ArrayList<>();
                if (letter1 == letter2) {
                    if (IS_DEBUG_MODE) {
                        System.out.println("Same Letters");
                    }

                    for (int i = num1; i < num2; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                    for (int i = num2; i < num1; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                }
                if (num1 == num2) {
                    for (char c = letter1; c < letter2; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                    for (char c = letter2; c < letter1; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                }

                if (IS_DEBUG_MODE) {
                    System.out.println("Removing Intersections");
                }

                // Searches for the buttons in path, and if it finds that the button isn't
                // occupied, it removes it.
                ObservableList<Node> buttons = playerGrid.getChildren();
                int counter2 = 0;
                for (Node b : buttons) {
                    Button button = (Button) b;
                    if (path.contains(button.getText())) {
                        path.remove(button.getText());
                    }
                    counter2++;
                    if (counter2 == 100)
                        break;
                }
                // When the above for loop finishes, path will contain the coordinates of any
                // occupied button,
                // so if path isn't empty, the path would intersect with another ship, so we
                // remove that option
                if (IS_DEBUG_MODE) {
                    System.out.println("Checking Intersections");
                }

                if (path.size() != 0) {
                    options.remove(option);
                }

            }

            if (IS_DEBUG_MODE) {
                System.out.println("Disabling Buttons");
            }

            // Disable any button that isn't contained in the good options list.
            ObservableList<Node> test = playerGrid.getChildren();
            int counter = 0;
            for (Node t : test) {

                Button b = (Button) t;

                if (!options.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    b.setDisable(true);
                }

                counter++;
                if (counter == 100)
                    break;
            }
            // Tells the method that we have placed the "head" of our ship
            startPlacement = false;

        }
        // we've placed the head, so now we are placing the tail
        else {
            ArrayList<String> greyedOut = new ArrayList<>();
            // int x = 0;

            // Break up strings letter and number
            char letter2 = p.charAt(0);
            int num2;
            num2 = Integer.parseInt(p.substring(1, p.length()));

            // Break up the firstPlace letter and number
            char letter1 = firstPlace.charAt(0);
            int num1;
            num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

            String newS = letter1 + "" + num1;
            greyedOut.add(newS);
            newS = letter2 + "" + num2;
            greyedOut.add(newS);

            if (IS_DEBUG_MODE) {
                System.out.println("Building Path");
            }

            // Add all the buttons between button1 and button2 to be greyed out
            if (letter1 == letter2) {
                for (int i = num1; i < num2; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
                for (int i = num2; i < num1; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
            }
            if (num1 == num2) {
                for (char c = letter1; c < letter2; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
                for (char c = letter2; c < letter1; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
            }

            // Disable buttons for the path, sets abbreviations, enables buttons that should
            // be enabled afterwards
            if (IS_DEBUG_MODE) {
                System.out.println("Enabling Buttons");
            }

            ObservableList<Node> test = playerGrid.getChildren();
            int counter = 0;
            for (Node t : test) {

                Button b = (Button) t;

                if (greyedOut.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    placedCoords.add(b.getText());
                    if (greyedOut.contains(b.getText())) {
                        b.setText(b.getText() + abbr);
                        b.setStyle("-fx-background-color: #696969;");
                        shipAbbr.add(b.getText());
                    }

                    b.setDisable(true);

                } else {
                    b.setDisable(false);
                }

                counter++;
                if (counter == 100)
                    break;

            }
            // Says we are ready for the next head ship
            startPlacement = true;

        }

    }

    void disableOponentGrid() {
        // Disables all buttons on the top grid

        ObservableList<Node> test = oponentGrid.getChildren();
        System.out.println("Disabling Grid");
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(true);
            counter++;
            if (counter == 100)
                break;
        }
    }

    void enableOponentGrid() {
        // Disables all buttons on the top grid

        ObservableList<Node> test = oponentGrid.getChildren();
        System.out.println("Disabling Grid");
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            if (b.getText().contains("Hit") || b.getText().contains("Miss")) {
                b.setDisable(true);
            } else {
                b.setDisable(false);
            }

            counter++;
            if (counter == 100)
                break;
        }
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/Gameboard.fxml"));
        primaryStage.setTitle("Battleship");
        primaryStage.setScene(new Scene(root, 1200, 800));
        primaryStage.show();

    }

    public static void main(String[] args) {
        clientToServer.email = args[0];
        clientToServer.gameID = "12345";
        launch(args);
    }
}