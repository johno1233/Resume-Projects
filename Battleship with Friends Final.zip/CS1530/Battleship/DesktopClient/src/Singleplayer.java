import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Stack;

public class Singleplayer {
    public static boolean practiceMode = false;
    public static String email = "";
    public static ArrayList<String> playerBoard = new ArrayList<>();
    public static ArrayList<String> cpuBoard = new ArrayList<>();
    public static HashMap<String, Ship> ships = new HashMap<>();
    public static ArrayList<Ship> shipsList = new ArrayList<Ship>();
    public static HashMap<String, String> coordsToShips = new HashMap<>();
    public static ArrayList<String> playerShots = new ArrayList<>();
    public static ArrayList<String> cpuShots = new ArrayList<>();
    public static String winner = "";
    public static int difficulty = 1;
    public static Stack<String> hardModeStack = new Stack<>();

    public static Random rand = new Random();

    public static String fireShot(String shot) {
        playerShots.add(shot);
        if (cpuBoard.contains(shot)) {
            String res = "Hit the ";
            String ship = coordsToShips.get(shot);
            res += ship;
            ships.get(ship).hit();
            if (ships.get(ship).isSunk()) {
                res += " And it sunk";
            }
            res += "!";
            return res;
        } else {
            return "Missed!";
        }

    }

    public static void createShips() {
        ships.put("Carrier", new Ship("Carrier", "CA", 5));
        ships.put("Battleship", new Ship("Battleship", "BS", 4));
        ships.put("Cruiser", new Ship("Cruiser", "CR", 3));
        ships.put("Submarine", new Ship("Submarine", "SB", 3));
        ships.put("Destroyer", new Ship("Destroyer", "DS", 2));
        shipsList = new ArrayList<Ship>(ships.values());
    }

    public static void storeBoard(ArrayList<String> board) {
        playerBoard = board;
        System.out.println(playerBoard);
    }

    public static void cpuCreateBoard() {
        Boolean goodPlacement = false;
        int shipNum = 0;
        do {
            Ship curr = shipsList.get(shipNum);

            System.out.println("Placing Ship " + curr);
            char letter = (char) (rand.nextInt(10) + 65);
            int num = rand.nextInt(10) + 1;
            StringBuilder sb = new StringBuilder();
            sb.append(letter);
            sb.append(num);
            String start = sb.toString();
            if (cpuBoard.contains(start)) {
                continue;
            }

            ArrayList<String> coords = finishPlacingShip(letter, num, curr.length - 1);
            coords.add(start);
            System.out.println(coords);
            Boolean intersections = false;
            for (String c : coords) {
                if (cpuBoard.contains(c)) {
                    intersections = true;
                    break;
                }
            }
            if (intersections) {
                continue;
            }
            for (String c : coords) {
                cpuBoard.add(c);
                coordsToShips.put(c, curr.name);
            }
            System.out.println("Placed Ship " + curr);
            shipNum++;
            // goodPlacement = true;
        } while (shipNum < 5);

    }

    public static Boolean isGameOver() {
        Boolean hasWon = true;
        System.out.println(cpuBoard);
        for (String coord : cpuBoard) {
            if (!playerShots.contains(coord)) {
                System.out.println("Player Hasn't won");

                hasWon = false;
                break;
            }
        }
        if (hasWon) {
            winner = "You";
            return true;
        }
        hasWon = false;
        for (String coord : playerBoard) {
            if (!cpuShots.contains(coord)) {

                System.out.println("CPU Hasn't won " + coord);
                return false;
            }
        }
        winner = "Computer";
        return true;
    }

    public static String cpuFire() throws InterruptedException {
        String shot = "";
        if (difficulty == 1) {
            shot = easyMode();
            System.out.println(shot);
        } else if (difficulty == 2) {
            shot = hardMode();
        } else if (difficulty == 3) {
            shot = perfectMode();
        } else {
            return "Invalid Difficulty";
        }

        for (String coord : playerBoard) {
            if (coord.contains(shot)
                    && ((shot.length() == 2 && coord.length() == 4) || (shot.length() == 3 && coord.length() == 5))) {
                // Hit
                cpuShots.add(shot);
                cpuShots.add(coord);
                return coord;
            }
        }
        // Miss
        cpuShots.add(shot);
        return shot;

    }

    public static String easyMode() {
        Boolean goodShot = true;
        String shot = "";
        do {
            char letter = (char) (rand.nextInt(10) + 65);
            int num = rand.nextInt(10) + 1;
            StringBuilder sb = new StringBuilder();
            sb.append(letter);
            sb.append(num);
            shot = sb.toString();
            goodShot = !cpuShots.contains(shot);
        } while (!goodShot);

        return shot;
    }

    public static String hardMode() {
        String shot = "";
        if (hardModeStack.size() == 0) {
            shot = easyMode();
        } else {
            shot = hardModeStack.pop();
        }

        for (String coord : playerBoard) {
            if (coord.contains(shot)
                    && ((shot.length() == 2 && coord.length() == 4) || (shot.length() == 3 && coord.length() == 5))) {
                // Hit
                char letter = shot.charAt(0);
                int num = Integer.parseInt(shot.substring(1, shot.length()));

                StringBuilder sb = new StringBuilder();

                // Up
                int newNum = num - 1;
                if (newNum != 0) {
                    sb.append(letter);
                    sb.append(newNum);
                    String nextShot = sb.toString();
                    if (!cpuShots.contains(nextShot) && !hardModeStack.contains(nextShot)) {
                        hardModeStack.push(nextShot);
                    }

                }

                sb = new StringBuilder();
                // Oh java
                letter--;
                char newLetter = letter;
                letter++;
                // Left
                if (newLetter != '@') {
                    sb.append(newLetter);
                    sb.append(num);
                    String nextShot = sb.toString();
                    if (!cpuShots.contains(nextShot) && !hardModeStack.contains(nextShot)) {
                        hardModeStack.push(nextShot);
                    }
                }

                // Down
                sb = new StringBuilder();
                newNum = num + 1;
                if (newNum != 11) {
                    sb.append(letter);
                    sb.append(newNum);
                    String nextShot = sb.toString();
                    if (!cpuShots.contains(nextShot) && !hardModeStack.contains(nextShot)) {
                        hardModeStack.push(nextShot);
                    }
                }

                sb = new StringBuilder();
                // Oh java
                letter++;
                newLetter = letter;
                letter--;
                // Right
                if (newLetter != 'K') {
                    sb.append(newLetter);
                    sb.append(num);
                    String nextShot = sb.toString();
                    if (!cpuShots.contains(nextShot) && !hardModeStack.contains(nextShot)) {
                        hardModeStack.push(nextShot);
                    }
                }
                System.out.println("Stack " + hardModeStack);
                System.out.println("CPU Shots" + cpuShots);
                break;
            }

        }
        return shot;
    }

    public static String perfectMode() {
        Boolean goodShot = true;
        String shot = "";
        do {
            int index = rand.nextInt(playerBoard.size());
            shot = playerBoard.get(index);
            goodShot = !cpuShots.contains(shot);
        } while (!goodShot);
        return shot;
    }

    public static String getWinner() {
        return winner;
    }

    private static ArrayList<String> finishPlacingShip(char letter, int num, int length) {
        ArrayList<ArrayList<String>> choices = new ArrayList<>();
        ArrayList<String> up = new ArrayList<>();
        ArrayList<String> down = new ArrayList<>();
        ArrayList<String> left = new ArrayList<>();
        ArrayList<String> right = new ArrayList<>();

        if (num - length > 0) {
            // System.out.println("Placing Up");
            for (int i = num - length; i < num; i++) {
                StringBuilder sb = new StringBuilder();
                sb.append(letter);
                sb.append(i);
                up.add(sb.toString());
            }
            choices.add(up);
        }
        if (num + length <= 10) {
            // System.out.println("Placing Down");
            for (int i = num + length; i > num; i--) {
                StringBuilder sb = new StringBuilder();
                sb.append(letter);
                sb.append(i);
                down.add(sb.toString());
            }
            choices.add(down);
        }
        if (letter - length > 64) {
            // 64 is ASCII char before A
            // System.out.println("Placing Left");
            for (char c = (char) (letter - length); c < letter; c++) {
                StringBuilder sb = new StringBuilder();
                sb.append(c);
                sb.append(num);
                left.add(sb.toString());
            }
            choices.add(left);
        }
        if (letter + length < 75) {
            // 75 is ASCII char after J
            // System.out.println("Placing Right");
            for (char c = (char) (letter + length); c > letter; c--) {
                StringBuilder sb = new StringBuilder();
                sb.append(c);
                sb.append(num);
                right.add(sb.toString());
            }
            choices.add(right);
        }

        // System.out.println(choices);
        int choice = rand.nextInt(choices.size());
        return choices.get(choice);
    }
}