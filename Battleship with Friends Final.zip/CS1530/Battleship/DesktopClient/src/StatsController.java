import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.util.HashMap;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import javafx.scene.control.Button;
import javafx.event.ActionEvent;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;
import javafx.collections.ObservableList;
import javafx.scene.Node;

public class StatsController {

    @FXML
    private Label emailLabel;

    @FXML
    private Label winsLabel;

    @FXML
    private Label lossesLabel;

    @FXML
    private Label plusMinusLabel;

    @FXML
    private Button mainmenuButton;

    public StatsController() {
    }

    @FXML
    private void initialize() {
    }

    @FXML
    void setLabels() {
        String email = clientToServer.email;
        HashMap<String, Integer> stats = clientToServer.getStats(email);

        emailLabel.setText(email);
        winsLabel.setText(stats.get("wins").toString());
        lossesLabel.setText(stats.get("losses").toString());
        plusMinusLabel.setText(stats.get("plusMinus").toString());
        
        emailLabel.setAlignment(Pos.CENTER);
        winsLabel.setAlignment(Pos.CENTER);
        lossesLabel.setAlignment(Pos.CENTER);
        plusMinusLabel.setAlignment(Pos.CENTER);
    }

    @FXML
    void goToMainMenu(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }
}