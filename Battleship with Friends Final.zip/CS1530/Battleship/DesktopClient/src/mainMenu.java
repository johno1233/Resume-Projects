import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.control.PasswordField;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;

public class mainMenu extends Application {

    @FXML
    private Button multiplayerButton;

    @FXML
    private Button statsButton;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
        primaryStage.setTitle("Main Menu");
        primaryStage.setScene(new Scene(root, 800, 800));
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

    @FXML
    void multiplayerPressed(ActionEvent event) throws IOException {

        System.out.println("Multiplayer Pressed");

        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/MultiplayerQueue.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Multiplayer Mode");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();

    }

    @FXML
    void singleplayerPressed(ActionEvent event) throws IOException {
        System.out.println("Single Player");
        Singleplayer.practiceMode = false;
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/Singleplayer.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Singleplayer Mode");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    void practicePressed(ActionEvent event) throws IOException {
        System.out.println("Practice");
        Singleplayer.practiceMode = true;
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/Singleplayer.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Practice Mode");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    void statsPressed(ActionEvent event) throws IOException {

        System.out.println("Stats Pressed");

        // clientToServer.updateStats(clientToServer.email, "win");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("DesktopClient/src/Stats.fxml"));

        Stage stage = new Stage();
        stage.setTitle("Game Statistics");
        stage.setScene(new Scene(loader.load(), 800, 800));

        StatsController controller = loader.<StatsController>getController();
        controller.setLabels();

        stage.show();

        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    void goToSettings(ActionEvent event) throws IOException{
        System.out.println("Settings");
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/Settings.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Settings");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

}
