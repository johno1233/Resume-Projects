import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.concurrent.Task;

import javafx.application.Platform;
import javafx.application.*;

import java.io.IOException;
import java.util.HashMap;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.fxml.FXMLLoader;

public class MultiplayerQueue {

    @FXML
    private Label statusLabel;

    @FXML
    private Pane pane;

    @FXML
    void initialize() throws InterruptedException, IOException {
        System.out.println("Loaded");
        statusLabel.setText("Waiting For Others");

        Stage window = new Stage();

        Task<String> queue = new Task<String>() {
            @Override
            protected String call() throws Exception {
                HashMap<String, String> map = clientToServer.multiPlayerGame(clientToServer.email);
                String gameID = map.get("gameID");
                clientToServer.gameID = gameID;
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            statusLabel.setText("Found Player");
                            Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/Gameboard.fxml"));
                            Stage stage = new Stage();
                            stage.setTitle("Multiplayer Mode");
                            stage.setScene(new Scene(root, 800, 800));
                            stage.show();
                            Stage s = (Stage) statusLabel.getScene().getWindow();
                            s.close();
                        } catch (Exception e) {
                            // TODO: handle exception
                        }

                    }
                });
                // Thread.sleep(10000);
                return gameID;
            }
        };

        Thread th = new Thread(queue);
        th.setDaemon(true);
        th.start();

        // clientToServer.multiPlayerGame(clientToServer.email);

    }
}
