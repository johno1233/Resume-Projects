import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;
import javafx.collections.ObservableList;
import javafx.scene.Node;

public class SingleplayerBoard extends Application {
    public static ArrayList<Ship> ships = new ArrayList<>();
    int shipNum = 0;
    Boolean startPlacement = true;
    public String firstPlace = "";
    Boolean IS_DEBUG_MODE = false;

    public ArrayList<String> shipAbbr = new ArrayList<>();

    public ArrayList<String> shots = new ArrayList<>();

    public ArrayList<String> placedCoords = new ArrayList<>();

    @FXML
    private Button a1;

    @FXML
    private Button a11;

    @FXML
    private GridPane playerGrid;

    @FXML
    private Button mainMenuButton;

    @FXML
    private Pane background;

    @FXML
    private GridPane oponentGrid;

    @FXML
    private Label boardLabel;

    @FXML
    private Label statusLabel;

    @FXML
    void fire(ActionEvent event) throws Exception {
        Button b = (Button) event.getSource();
        String shot = b.getText();
        String result = Singleplayer.fireShot(shot);
        statusLabel.setText("You " + result);
        if (result.contains("Hit")) {
            b.setText("Hit");
        } else {
            b.setText("Miss");
        }
        b.setDisable(true);
        sleep();
        Boolean res = Singleplayer.isGameOver();
        if (res) {
            disableOponentGrid();
            statusLabel.setText("You Win!");
            if (!Singleplayer.practiceMode) {
                clientToServer.updateStats(clientToServer.email, "win");

            }
            mainMenuButton.setVisible(true);
            return;
        }
        String cpuShot = Singleplayer.cpuFire();
        updatePlayerGrid(cpuShot);

        res = Singleplayer.isGameOver();
        if (res) {
            disableOponentGrid();
            statusLabel.setText("You Lose!");
            if (!Singleplayer.practiceMode) {
                clientToServer.updateStats(clientToServer.email, "loss");
            }
            mainMenuButton.setVisible(true);
            return;
        }

    }

    @FXML
    void place(ActionEvent event) {
        Button b = (Button) event.getSource();
        System.out.println(b.getText());
        Ship curr = ships.get(shipNum);

        updatePlaceBoard(b.getText(), curr.length - 1, curr.abbr);
        // placedCoords.add(b.getText()+curr.abbr);
        if (!startPlacement) {
            statusLabel.setText("Enter the ending Coord for " + curr.toString());
        } else {
            shipNum++;
            if (shipNum != 5) {
                statusLabel.setText("Enter the starting Coord for " + ships.get(shipNum).toString());
            } else {
                // statusLabel.setText("Done Placing Ships, waiting for match to begin");
                disablePlayerGrid();

                ArrayList<String> board = new ArrayList<>();

                ObservableList<Node> test = playerGrid.getChildren();
                int counter = 0;
                for (Node t : test) {

                    Button button = (Button) t;
                    String coord = button.getText();
                    if (coord.length() >= 4) {
                        board.add(coord);
                    }
                    counter++;
                    if (counter == 100)
                        break;
                }

                // for (String coord : placedCoords) {
                // if (coord.length() >= 3) {
                // board.add(coord);
                // }
                // }
                System.out.println(board);
                Singleplayer.storeBoard(board);
                String status = "Your Turn";
                statusLabel.setText(status);
                enableOponentGrid();
            }
        }
    }

    @FXML
    void initialize() throws InterruptedException {
        // Start the game!
        disableOponentGrid();
        enablePlayerGrid();

        if(!Singleplayer.practiceMode){
            int diff = clientToServer.getSettings();
            Singleplayer.difficulty = diff;
        }

        Singleplayer.createShips();
        ships = new ArrayList<Ship>(Singleplayer.ships.values());

        statusLabel.setText("Enter the starting Coord for " + ships.get(0).toString());
        mainMenuButton.setVisible(false);
        Singleplayer.cpuCreateBoard();

    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/SinglePlayer.fxml"));
        primaryStage.setTitle("Battleship");
        primaryStage.setScene(new Scene(root, 800, 800));
        primaryStage.show();

    }

    public static void main(String[] args) {
        Singleplayer.email = args[0];
        launch(args);
    }

    void disableOponentGrid() {
        // Disables all buttons on the top grid

        ObservableList<Node> test = oponentGrid.getChildren();
        System.out.println("Disabling Grid");
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(true);
            counter++;
            if (counter == 100)
                break;
        }
    }

    void enableOponentGrid() {
        // Disables all buttons on the top grid

        ObservableList<Node> test = oponentGrid.getChildren();
        System.out.println("Disabling Grid");
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            if (b.getText().contains("Hit") || b.getText().contains("Miss")) {
                b.setDisable(true);
            } else {
                b.setDisable(false);
            }

            counter++;
            if (counter == 100)
                break;
        }
    }

    void updatePlayerGrid(String button) {
        // Disables all the buttons on the player's (bottom) grid)
        System.out.println("Update Player GRID" + button);
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            if (b.getText().equals(button)) {
                // Missed
                if(b.getText().length() >=4){
                    //hit 
                    b.setStyle("-fx-background-color: #EF1F14;");
                }
                else{
                    //Missed 
                    b.setStyle("-fx-background-color: #10A6EA;");
                }
               
            } 
            counter++;
            if (counter == 100)
                break;
        }
    }

    void enablePlayerGrid() {
        // Enables all the buttons on the player's (bottom) grid
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(false);
            counter++;
            if (counter == 100)
                break;
        }
    }

    void disablePlayerGrid() {
        // Disables all the buttons on the player's (bottom) grid)
        ObservableList<Node> test = playerGrid.getChildren();
        int counter = 0;
        for (Node t : test) {

            Button b = (Button) t;
            b.setDisable(true);
            counter++;
            if (counter == 100)
                break;
        }
    }

    @FXML
    void goToMainMenu(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    public void updatePlaceBoard(String p, int length, String abbr) {
        // Method that disables buttons that need to be disabled, and updates button
        // labels

        // Add ship abbreviation to list
        shipAbbr.add(abbr);
        if (IS_DEBUG_MODE) {
            System.out.println(startPlacement);
        }

        // If we are placing the "head" of the ship
        if (startPlacement) {
            ArrayList<String> options = new ArrayList<>();
            // int x = 0;

            // Seperate number and letter from string.
            char letter = p.charAt(0);
            int num;
            num = Integer.parseInt(p.substring(1, p.length()));
            // Save this location for when we place the "tail" of the ship
            firstPlace = letter + "" + num;

            // Add all possible tail values, depending on the length of the ship
            char newL = (char) (letter - length);
            String newS = newL + "" + num;
            options.add(newS);

            newL = (char) (letter + length);
            newS = newL + "" + num;
            options.add(newS);

            int newN = num - length;
            newS = letter + "" + newN;
            options.add(newS);

            newN = num + length;
            newS = letter + "" + newN;
            options.add(newS);

            // Create a copy of options because we will be destorying options2
            ArrayList<String> options2 = new ArrayList<>();
            for (String option : options) {
                options2.add(option);
            }

            // Checks to make sure intersections are not allowed.
            for (String option : options2) {
                char letter1 = firstPlace.charAt(0);
                int num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

                char letter2 = option.charAt(0);
                int num2 = Integer.parseInt(option.substring(1, option.length()));

                // Lists all buttons that would be disabled if the user were to select that
                // specific option
                ArrayList<String> path = new ArrayList<>();
                if (letter1 == letter2) {
                    if (IS_DEBUG_MODE) {
                        System.out.println("Same Letters");
                    }

                    for (int i = num1; i < num2; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                    for (int i = num2; i < num1; i++) {
                        newS = letter1 + "" + i;
                        path.add(newS);
                    }
                }
                if (num1 == num2) {
                    for (char c = letter1; c < letter2; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                    for (char c = letter2; c < letter1; c++) {
                        newS = c + "" + num1;
                        path.add(newS);
                    }
                }

                if (IS_DEBUG_MODE) {
                    System.out.println("Removing Intersections");
                }

                // Searches for the buttons in path, and if it finds that the button isn't
                // occupied, it removes it.
                ObservableList<Node> buttons = playerGrid.getChildren();
                int counter2 = 0;
                for (Node b : buttons) {
                    Button button = (Button) b;
                    if (path.contains(button.getText())) {
                        path.remove(button.getText());
                    }
                    counter2++;
                    if (counter2 == 100)
                        break;
                }
                // When the above for loop finishes, path will contain the coordinates of any
                // occupied button,
                // so if path isn't empty, the path would intersect with another ship, so we
                // remove that option
                if (IS_DEBUG_MODE) {
                    System.out.println("Checking Intersections");
                }

                if (path.size() != 0) {
                    options.remove(option);
                }

            }

            if (IS_DEBUG_MODE) {
                System.out.println("Disabling Buttons");
            }

            // Disable any button that isn't contained in the good options list.
            ObservableList<Node> test = playerGrid.getChildren();
            int counter = 0;
            for (Node t : test) {

                Button b = (Button) t;

                if (!options.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    b.setDisable(true);
                }

                counter++;
                if (counter == 100)
                    break;
            }
            // Tells the method that we have placed the "head" of our ship
            startPlacement = false;

        }
        // we've placed the head, so now we are placing the tail
        else {
            ArrayList<String> greyedOut = new ArrayList<>();
            // int x = 0;

            // Break up strings letter and number
            char letter2 = p.charAt(0);
            int num2;
            num2 = Integer.parseInt(p.substring(1, p.length()));

            // Break up the firstPlace letter and number
            char letter1 = firstPlace.charAt(0);
            int num1;
            num1 = Integer.parseInt(firstPlace.substring(1, firstPlace.length()));

            String newS = letter1 + "" + num1;
            greyedOut.add(newS);
            newS = letter2 + "" + num2;
            greyedOut.add(newS);

            if (IS_DEBUG_MODE) {
                System.out.println("Building Path");
            }

            // Add all the buttons between button1 and button2 to be greyed out
            if (letter1 == letter2) {
                for (int i = num1; i < num2; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
                for (int i = num2; i < num1; i++) {
                    newS = letter1 + "" + i;
                    greyedOut.add(newS);
                }
            }
            if (num1 == num2) {
                for (char c = letter1; c < letter2; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
                for (char c = letter2; c < letter1; c++) {
                    newS = c + "" + num1;
                    greyedOut.add(newS);
                }
            }

            // Disable buttons for the path, sets abbreviations, enables buttons that should
            // be enabled afterwards
            if (IS_DEBUG_MODE) {
                System.out.println("Enabling Buttons");
            }

            ObservableList<Node> test = playerGrid.getChildren();
            int counter = 0;
            for (Node t : test) {

                Button b = (Button) t;

                if (greyedOut.contains(b.getText()) || shipAbbr.contains(b.getText())) {
                    placedCoords.add(b.getText());
                    if (greyedOut.contains(b.getText())) {
                        b.setText(b.getText() + abbr);
                        b.setStyle("-fx-background-color: #696969;");
                        shipAbbr.add(b.getText());
                    }

                    b.setDisable(true);

                } else {
                    b.setDisable(false);
                }

                counter++;
                if (counter == 100)
                    break;

            }
            // Says we are ready for the next head ship
            startPlacement = true;

        }

    }

    public void sleep() throws Exception {
        Task<String> wait = new Task<String>() {
            @Override
            protected String call() throws Exception {
                Thread.sleep(1000);
                return "";
            }

        };
        Thread th = new Thread(wait);
        th.setDaemon(true);
        th.start();

    }

}
