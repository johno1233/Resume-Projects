import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.control.PasswordField;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;

public class LoginWindow extends Application {

    @FXML
    private TextField usernameTF;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private Button registerButton;

    @FXML
    private Button loginButton;

    @FXML
    private Label loginStatusLabel;

    @FXML
    private Button practiceButton;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/LoginWindow.fxml"));
        primaryStage.setTitle("Battleship");
        primaryStage.setScene(new Scene(root, 800, 800));
        primaryStage.show();

        // Thread.sleep(5000);

    }

    public static void main(String[] args) {
        launch(args);
    }

    @FXML
    void loginPressed(ActionEvent event) throws IOException {
        try {
            System.out.println("Login Pressed");

            String email = usernameTF.getText();
            String password = passwordTF.getText();

            boolean result = clientToServer.login(email, password);
            if (result) {
                clientToServer.email = email;
                Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Main Menu");
                stage.setScene(new Scene(root, 800, 800));
                stage.show();
                // Hide this current window (if this is what you want)
                ((Node) (event.getSource())).getScene().getWindow().hide();
            } else {
                loginStatusLabel.setText("Invalid Login");
                loginStatusLabel.setTextFill(Color.RED);
            }
        } catch (Exception e) {
            practiceButton.setVisible(true);
            loginStatusLabel.setText("Unable to Connect to Server");
        }

    }

    @FXML
    void registerPressed(ActionEvent event) throws IOException, InterruptedException {
        System.out.println("Register Pressed");
        String email = usernameTF.getText();
        String password = passwordTF.getText();
        String pattern = "(?=.*[0-9]).{8,}";
        if (!password.matches(pattern)) {
            loginStatusLabel.setText("Please choose a secure password");
            loginStatusLabel.setTextFill(Color.RED);
            return;
        }
        boolean result = clientToServer.register(email, password);
        if (result) {
            loginStatusLabel.setText("Account Created, Logging In");
            // Thread.sleep(5000);
            loginPressed(event);
        } else {
            loginStatusLabel.setText("Account Creation Failed");
            loginStatusLabel.setTextFill(Color.RED);
        }
    }

    @FXML
    void practiceButtonPressed(ActionEvent event) {
        System.out.println("Not Implemented Yet");
    }

}