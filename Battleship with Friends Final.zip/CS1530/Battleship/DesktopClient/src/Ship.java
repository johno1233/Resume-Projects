public class Ship {
    String name;
    String abbr;
    int length;
    int hits;

    public Ship(String n, String ab, int len) {
        name = n;
        abbr = ab;
        length = len;
        hits = 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name);
        sb.append("(Length: ");
        sb.append(length);
        sb.append(")");
        return sb.toString();
    }
    public void hit() {
        hits++;
    }
    public Boolean isSunk() {
        return hits == length;
    }

}