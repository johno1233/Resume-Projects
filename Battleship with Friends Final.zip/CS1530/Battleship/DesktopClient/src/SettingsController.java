import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;
import javafx.collections.ObservableList;
import javafx.scene.Node;

import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class SettingsController {

    @FXML
    private Label serverStatus;

    @FXML
    private Button mainMenu;

    @FXML
    private TextField serverTF;

    @FXML
    private RadioButton impossible;

    @FXML
    private RadioButton hard;

    @FXML
    private Button saveSettings;

    @FXML
    private RadioButton easy;

    @FXML
    private Button resetButton;

    @FXML
    void save(ActionEvent event) {

        int singleplayerdiff = 1;
        if(hard.isSelected()){
            singleplayerdiff = 2;
        }
        if(impossible.isSelected()){
            singleplayerdiff = 3;
        }
        System.out.println(serverTF.getText());
        System.out.println(singleplayerdiff);

        clientToServer.uploadSettings(singleplayerdiff);
    }

    @FXML
    void hardClicked(ActionEvent event) {
        easy.setSelected(false);
        impossible.setSelected(false);
        hard.setSelected(true);
    }

    @FXML
    void impossibleClicked(ActionEvent event) {
        easy.setSelected(false);
        impossible.setSelected(true);
        hard.setSelected(false);
    }

    @FXML
    void easyClicked(ActionEvent event) {
        easy.setSelected(true);
        impossible.setSelected(false);
        hard.setSelected(false);
    }

    @FXML
    void reset(ActionEvent event) {

    }
    @FXML
    void initialize() {
        serverStatus.setVisible(false);
        int diff = clientToServer.getSettings();
        if(diff == 1){
            easyClicked(null);
        }
        else if(diff == 2){
            hardClicked(null);
        }
        else if(diff == 3){
            impossibleClicked(null);
        }
    }

    @FXML
    void goToMainMenu(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DesktopClient/src/mainMenu.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

}
