import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.control.PasswordField;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.concurrent.Task;

public class LoginWindow extends Application {

    @FXML
    private TextField usernameTF;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private Button registerButton;

    @FXML
    private Button loginButton;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginWindow.fxml"));
        primaryStage.setTitle("Battleship");
        primaryStage.setScene(new Scene(root, 600, 400));

        primaryStage.show();
        // Thread.sleep(5000);

    }

    public static void main(String[] args) {
        launch(args);
    }

    @FXML
    void loginPressed(ActionEvent event) throws IOException {
        System.out.println("Login Pressed");

        Parent root = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        Stage stage = new Stage();
        stage.setTitle("My New Stage Title");
        stage.setScene(new Scene(root, 800, 800));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    void registerPressed(ActionEvent event) {
        System.out.println("Register Pressed");
        System.out.println(usernameTF.getText());
        System.out.println(passwordTF.getText());
    }

}