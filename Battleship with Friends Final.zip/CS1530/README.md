# CS1530
Various Files and Assignments for CS 1530 Fall 2018

In the Battleship folder to run the game server as of 10/19/2018:


First install the requirements

```pip install -r Server/requirements.txt```

Then to run the server: 
```python3 Server/run.py```

The compile the desktop client in Battleship
```javac -classpath DesktopClient/src/json-20180813.jar DesktopClient/src/*.java -d DesktopClient/out/```

To run the Desktop client:
```java -cp DesktopClient/out:DesktopClient/src/json-20180813.jar:. LoginWindow```
